#import <Foundation/Foundation.h>

//! Project version number for Lightway.
FOUNDATION_EXPORT double LightwayVersionNumber;

//! Project version string for Lightway.
FOUNDATION_EXPORT const unsigned char LightwayVersionString[];

/// Includes of libhelium public headers
#import "he.h"
